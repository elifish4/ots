
require 'onetime'

Onetime.info "Calling Onetime.load!..."
Onetime.load! :cli
